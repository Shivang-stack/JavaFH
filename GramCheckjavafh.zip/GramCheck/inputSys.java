import java.util.Scanner;
import javax.swing.*;
class inputSys
{
    public void input(String sen)throws Exception
    {
        Scanner sc=new Scanner (System.in);
        Reader obj=new Reader();
        Feeder f=new Feeder();

        //input

        String word="",nSen="";

        //Tokenizing

        //Number of words
        int nw=1;
        for(int x=0;x<=sen.length()-1;x++)
        {
            char ch=sen.charAt(x);
            if(ch==' ')
            {
                nw++;
            }
            if(ch!='.')
            {
                nSen+=ch;
            }
        }
        nSen+=" ";

        //Seperating words
        String senAr[]=new String[nw];
        int c=0;

        for(int x=0;x<=nSen.length()-1;x++)
        {
            char ch=nSen.charAt(x);    
            if(ch!=' ')
            {
                word+=ch;
            }
            else
            {
                if(!(obj.isWord(word)))//checking if word is correct or not
                {
                    String wrd=JOptionPane.showInputDialog(null,"Enter correct word(if already correct then enter @yes@)");
                    if(!(wrd.equals("@yes@")))
                    {
                        senAr[c++]=wrd;
                        f.WriteFile("wordlist.txt",wrd);//feeding into system
                    }
                    else
                    {
                        senAr[c++]=word;
                    }
                }
                else
                {
                    senAr[c++]=word;
                }
                word="";
            }
        }

        //Checking for POS and comprising the pattern of the sentence
        String senSt="";//Sentence Pattern Variable(SPV)
        for(int y=0;y<=nw-1;y++)
        {
            System.out.println(senAr[y]);
            int c2=0;
            //checking for POS
            if(obj.noun(senAr[y]))
            {
                senSt+="N,";c2++;//feeding into SPV
            }
            if(obj.pronoun(senAr[y]))
            {
                senSt+="P,";c2++;
            }
            if(obj.verb(senAr[y]))
            {
                senSt+="V,";c2++;
            }
            if(obj.adverb(senAr[y]))
            {
                senSt+="AV,";c2++;
            }
            if(obj.adjective(senAr[y]))
            {
                senSt+="AD,";c2++;
            }
            if(c==0)//checking for Undefined word and feeding them into system accorrdingly
            {
                String res=JOptionPane.showInputDialog(null,senAr[y]+" is not in System please define it.\n1-Subject/object\n2-pronoun\n3-verb\n4-adverb\n5-adjective");
                f.feed(Integer.parseInt(res),senAr[y]);
            }

        }
        JOptionPane.showMessageDialog(null,"Result : "+senSt);//printing pattern

    }
}