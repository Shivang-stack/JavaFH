import java.io.*;
import java.util.Scanner;
class Feeder
{
    public void  feed(int num, String s)throws Exception //input 
    {
        if(num==1){WriteFile("subject.txt",s);}
        else if(num==2){WriteFile("pronoun.txt",s);}
        else if(num==3){WriteFile("verb.txt",s);}
        else if(num==4){WriteFile("adverb.txt",s);}
        else if(num==5){WriteFile("adjective.txt",s);}
        
    }
    
    public void WriteFile(String strFile,String strData)
    {
        try(BufferedWriter bfwriter= new BufferedWriter(new FileWriter(strFile,true)))
        {
            bfwriter.write(strData);
        }
        catch(Exception e){}
    }
}