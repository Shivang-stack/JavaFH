import java.util.Scanner;
import java.io.File;
class Reader
{
    //read from files and search for the words in system is found return true
    
    public static boolean verb(String S) throws Exception
    {
        String filename="POS/verb.csv";
        File file=new File(filename);
        Scanner inputStream=new Scanner(file);
        inputStream.next();
        while(inputStream.hasNext())
        {
            String data=inputStream.next();
            String[] verb= data.split(",");
            if(verb[0].equalsIgnoreCase(S))
            {
                inputStream.close();
                return true;
            }
        }
        inputStream.close();
        return false;
    }

    public static boolean noun(String S) throws Exception
    {
        String filename="POS/noun.txt";
        File file=new File(filename);
        Scanner inputStream=new Scanner(file);
        while(inputStream.hasNext())
        {
            String data=inputStream.next();
            if(data.equalsIgnoreCase(S))
            {
                inputStream.close();
                return true;
            }
        }
        inputStream.close();
        return false;
    }

    public static boolean adjective(String S) throws Exception
    {
        String filename="POS/adjective.txt";
        File file=new File(filename);
        Scanner inputStream=new Scanner(file);
        while(inputStream.hasNext())
        {
            String data=inputStream.next();
            if(data.equalsIgnoreCase(S))
            {
                inputStream.close();
                return true;
            }
        }
        inputStream.close();
        return false;
    }
    
     public static boolean adverb(String S) throws Exception
    {
        String filename="POS/adverb.txt";
        File file=new File(filename);
        Scanner inputStream=new Scanner(file);
        while(inputStream.hasNext())
        {
            String data=inputStream.next();
            if(data.equalsIgnoreCase(S))
            {
                inputStream.close();
                return true;
            }
        }
        inputStream.close();
        return false;
    }
    
    public static boolean pronoun(String S) throws Exception
    {
        String filename="POS/pronoun.txt";
        File file=new File(filename);
        Scanner inputStream=new Scanner(file);
        while(inputStream.hasNext())
        {
            String data=inputStream.next();
            if(data.equalsIgnoreCase(S))
            {
                inputStream.close();
                return true;
            }
        }
        inputStream.close();
        return false;
    }
    
    //Search form wordlist
    public static boolean isWord(String S) throws Exception
    {
        String filename="wordlist.txt";
        File file=new File(filename);
        Scanner inputStream=new Scanner(file);
        while(inputStream.hasNext())
        {
            String data=inputStream.next();
            if(data.equalsIgnoreCase(S))
            {
                inputStream.close();
                return true;
            }
        }
        inputStream.close();
        return false;
    }
}