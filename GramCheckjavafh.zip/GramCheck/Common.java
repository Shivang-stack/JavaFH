import java.util.Scanner;
import java.io.File;
class Common
{
    public static void main() throws Exception
    {
        String nounf="noun.txt";
        File noun=new File(nounf);
        
        
        String pronounf="pronoun.txt";
        File pronoun=new File(pronounf);
        
        
        String verbf="verb.csv";
        File verb=new File(verbf);
        
        
        String adverbf="adverb.txt";
        File adverb=new File(adverbf);
        
        
        String adjectivef="adjective.txt";
        File adjective=new File(adjectivef);
        
        Scanner inputStreamN=new Scanner(noun);
        Scanner inputStreamP=new Scanner(pronoun);
        Scanner inputStreamV=new Scanner(verb);
        Scanner inputStreamAV=new Scanner(adverb);
        Scanner inputStreamAD=new Scanner(adjective);
        
        inputStreamV.next();
        
        String ComIA="",ComN_P_V_AV="",ComN_P_V="",ComN_P="";
        while(inputStreamN.hasNext()&&inputStreamP.hasNext()&&inputStreamV.hasNext()&&inputStreamAV.hasNext()&&inputStreamAD.hasNext())
        {
            String dataN=inputStreamN.next();
            String dataP=inputStreamP.next();
            String dataV=inputStreamV.next();
            String[] verbW= dataV.split(",");
            String dataAV=inputStreamAV.next();
            String dataAD=inputStreamAD.next();
            
            if(dataN.equalsIgnoreCase(dataP)&&dataP.equalsIgnoreCase(verbW[0])&&verbW[0].equalsIgnoreCase(dataAV)&&dataAV.equalsIgnoreCase(dataAD))
            {
                ComIA+=dataN+",";
            }
            
            if(dataN.equalsIgnoreCase(dataP)&&dataP.equalsIgnoreCase(verbW[0])&&verbW[0].equalsIgnoreCase(dataAV))
            {
                ComN_P_V_AV+=dataN+",";
            }
            
            if(dataN.equalsIgnoreCase(dataP)&&dataP.equalsIgnoreCase(verbW[0]))
            {
                ComN_P_V+=dataN+",";
            }
            
            if(dataN.equalsIgnoreCase(dataP))
            {
                ComN_P+=dataN+",";
            }
        }
        
        System.out.println("Common in N-P-V-AV-AD : "+ComIA);
        System.out.println("Common in N-P-V-AV    : "+ComN_P_V_AV);
        System.out.println("Common in N-P-V       : "+ComN_P_V);
        System.out.println("Common in N-P         : "+ComN_P);
        
        inputStreamN.close();
        inputStreamP.close();
        inputStreamV.close();
        inputStreamAV.close();
        inputStreamAD.close();
        
    }
}